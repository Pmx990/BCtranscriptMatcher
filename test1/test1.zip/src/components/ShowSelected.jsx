import React from 'react'
import Course from './Course'


class ShowSelected extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            course : 'asd'
        }
    }

    

    render(){
        return <div >
            ｛course｝
            </div>
}   
    

}

export default ShowSelected;