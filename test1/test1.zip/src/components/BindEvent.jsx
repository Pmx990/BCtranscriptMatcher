import React from 'react'

 class BindEvent extends React.Component{
    constructor(){
        super();
        this.state={};
    }

render(){
    return <div>Test</div>
}

}

export default BindEvent;